import os
import pretty_midi

# Change this to your directory
MIDI_DIR = './'

# Helper to get instrument name
def get_instrument_name(instrument):
    if instrument.is_drum:
        return "Drums"
    return pretty_midi.program_to_instrument_name(instrument.program)

# Process MIDI files and print instruments
for filename in os.listdir(MIDI_DIR):
    if filename.lower().endswith(('.mid', '.midi')):
        file_path = os.path.join(MIDI_DIR, filename)
        try:
            midi_data = pretty_midi.PrettyMIDI(file_path)
            instruments = midi_data.instruments
            print(f"\n{filename}:")
            if not instruments:
                print("  No instruments found.")
            for i, inst in enumerate(instruments):
                name = get_instrument_name(inst)
                print(f"  Instrument {i + 1}: {name} {'(drum)' if inst.is_drum else ''}")
        except Exception as e:
            print(f"Error reading {filename}: {e}")
            print(f"Deleting {filename} due to read error.")
            try:
                os.remove(file_path)
            except Exception as delete_error:
                print(f"Failed to delete {filename}: {delete_error}")
